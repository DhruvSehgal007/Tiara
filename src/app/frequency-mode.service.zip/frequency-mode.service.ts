// src/app/frequency-mode.service.ts

import { Injectable } from '@angular/core';
import { BleClient, numbersToDataView } from '@capacitor-community/bluetooth-le';
import { buildFrame, DeviceFamily } from './ble-packets';

export interface FrequencyMode {
runTime: number;
stopTime: number;
enabled: boolean;
selectedDays: string[];
startHour: number;
startMinute: number;
endHour: number;
endMinute: number;
}

@Injectable({ providedIn: 'root' })
export class FrequencyModeService {
modes: { [key: string]: FrequencyMode } = {};

private connectedDeviceId = localStorage.getItem('connectedDeviceId') || '';
private svcUuid = '0000ffe0-0000-1000-8000-00805f9b34fb';
private chrUuid = '0000ffe1-0000-1000-8000-00805f9b34fb';
private looping = false;
private intervalId: number | null = null;

constructor() {
  this.loadFromStorage();
  // this.initializeDefaultModes();
}


initializeDefaultModes(count: number) {
for (let i = 1; i <= count; i++) {
  const key = `mode${i}`;
  if (!this.modes[key]) {
    this.modes[key] = {
      runTime: 10,
      stopTime: 60,
      enabled: false,
      selectedDays: [],
      startHour: 6,
      startMinute: 0,
      endHour: 22,
      endMinute: 0,
    };
  }
}
this.saveToStorage();
}


private loadFromStorage() {
  const data = localStorage.getItem('frequencyModes');
  if (data) this.modes = JSON.parse(data);
}

private saveToStorage() {
  localStorage.setItem('frequencyModes', JSON.stringify(this.modes));
}

getMode(modeId: string): FrequencyMode {
  return this.modes[modeId];
}

updateMode(
  modeId: string,
  runTime: number,
  stopTime: number,
  selectedDays: string[],
  startHour: number,
  startMinute: number,
  endHour: number,
  endMinute: number
) {
  this.modes[modeId] = {
    ...this.modes[modeId],
    runTime,
    stopTime,
    // selectedDays,
    selectedDays: selectedDays.map(d => d.toUpperCase()),
    startHour,
    startMinute,
    endHour,
    endMinute,
  };
  this.saveToStorage();
}

setEnabled(modeId: string, enabled: boolean) {
  if (this.modes[modeId]) {
    this.modes[modeId].enabled = enabled;
    this.saveToStorage();
  }
}

isEnabled(modeId: string): boolean {
  return this.modes[modeId]?.enabled ?? false;
}


getActiveModeId(): string | null {
this.loadFromStorage();

const keys = Object.keys(this.modes);  // mode1, mode2, mode3...
for (let key of keys) {
  if (this.modes[key]?.enabled) return key;
}
return null;
}

// async startFrequencyLoop(modeId: string) {

// this.loadFromStorage();
// const mode = this.modes[modeId];
// if (!mode || !mode.enabled || this.looping) return;

// // ---- FIX 1: TODAY DAY CHECK ----
// const today = new Date()
//   .toLocaleDateString('en-US', { weekday: 'short' })
//   .toUpperCase(); // MON, TUE, WED...

// const days = (mode.selectedDays || []).map(d => d.toUpperCase());

// if (!days.includes(today)) {
//   console.warn("❌ Day does not match:", today, days);
//   return;
// }

// // ---- FIX 2: TIME CHECK ----
// const now = new Date();
// const nowMin = now.getHours() * 60 + now.getMinutes();

// const startMin = (mode.startHour % 24) * 60 + mode.startMinute;
// const endMin = (mode.endHour % 24) * 60 + mode.endMinute;

// // handle crossing 2AM scenarios
// let insideTime = false;
// if (endMin >= startMin) {
//   insideTime = nowMin >= startMin && nowMin <= endMin;
// } else {
//   // e.g. start 22 → end 06
//   insideTime = nowMin >= startMin || nowMin <= endMin;
// }

// if (!insideTime) {
//   console.warn("❌ Not inside allowed time period");
//   return;
// }

// // ---- LOOP START ----
// this.looping = true;

// const loop = async () => {
//   if (!this.looping || !mode.enabled) {
//     await this.setPump(false);
//     return;
//   }

//   // await this.setPump(true);
// await this.setPump(true, mode.runTime);

//   setTimeout(async () => {
//     await this.setPump(false);

//     if (this.looping && mode.enabled) {
//       setTimeout(loop, mode.stopTime * 1000);
//     }
//   }, mode.runTime * 1000);
// };

// loop();
// }

async startFrequencyLoop(modeId: string) {

  this.loadFromStorage();
  const mode = this.modes[modeId];
  if (!mode || !mode.enabled || this.looping) return;

  // DAY CHECK ----------------
  const today = new Date()
    .toLocaleDateString('en-US', { weekday: 'short' })
    .toUpperCase();

  const days = (mode.selectedDays || []).map(d => d.toUpperCase());

  if (!days.includes(today)) return;

  // TIME CHECK ----------------
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();

  const startMin = mode.startHour * 60 + mode.startMinute;
  const endMin   = mode.endHour   * 60 + mode.endMinute;

  let inside = false;

  if (endMin >= startMin) {
    inside = nowMin >= startMin && nowMin <= endMin;
  } else {
    inside = nowMin >= startMin || nowMin <= endMin;
  }

  if (!inside) return;

  // LOOP START ----------------
  this.looping = true;

  const loop = async () => {
    if (!this.looping || !mode.enabled) {
      await this.setPump(false);
      return;
    }

    // TURN ON
    await this.setPump(true);

    // EXACT RUNTIME WAIT
    setTimeout(async () => {

      // TURN OFF
      await this.setPump(false);

      if (this.looping) {
        // EXACT STOP TIME WAIT
        setTimeout(loop, mode.stopTime * 1000);
      }

    }, mode.runTime * 1000);
  };

  loop();
}


stopLoop() {
  this.looping = false;
  if (this.intervalId) clearInterval(this.intervalId);
  this.setPump(false);
}

// private async setPump(on: boolean) {
// const command = [0x12, on ? 1 : 0, 0x00];
// const frame = buildFrame(DeviceFamily.Sanso, command);
// const data = numbersToDataView(Array.from(frame));

// try {
//   await BleClient.write(this.connectedDeviceId, this.svcUuid, this.chrUuid, data);
// } catch (err) {
//   console.error("Pump write failed", err);
// }
// }
private async setPump(on: boolean, runTime?: number) {

  let command;

  if (on) {
    command = [0x12, 1, runTime ?? 5];  // ⭐ send actual runtime here
  } else {
    command = [0x12, 0, 0x00];          // OFF stays same
  }

  const frame = buildFrame(DeviceFamily.Sanso, command);
  const data = numbersToDataView(Array.from(frame));

  try {
    await BleClient.write(this.connectedDeviceId, this.svcUuid, this.chrUuid, data);
  } catch (err) {
    console.error("Pump write failed", err);
  }
}

// ❗ REQUIRED — Your Bluetooth-lists uses this
startLoopForMode(modeId: string) {
return this.startFrequencyLoop(modeId);
}



saveMode(modeId: string, data: FrequencyMode) {
this.modes[modeId] = data; // ← update in-memory object
this.saveToStorage();      // ← update actual localStorage
}


async startFrequencyLoopDirect(runTime: number, stopTime: number) {
this.looping = true;

const loop = async () => {

  if (!this.looping) {
    await this.setPump(false);
    return;
  }

  // Pump ON
  await this.setPump(true);

  setTimeout(async () => {

    // Pump OFF
    await this.setPump(false);

    if (this.looping) {
      setTimeout(loop, stopTime * 1000);
    }

  }, runTime * 1000);
};

loop();
}



}
