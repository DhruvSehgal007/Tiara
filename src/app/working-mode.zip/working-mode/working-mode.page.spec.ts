import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WorkingModePage } from './working-mode.page';

describe('WorkingModePage', () => {
  let component: WorkingModePage;
  let fixture: ComponentFixture<WorkingModePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkingModePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
