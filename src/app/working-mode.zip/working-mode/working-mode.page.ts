import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FrequencyModeService } from '../frequency-mode.service';

@Component({
  selector: 'app-working-mode',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './working-mode.page.html',
  styleUrls: ['./working-mode.page.scss']
})
export class WorkingModePage implements OnInit {
  runTime = 10;
  stopTime = 60;
  enabled = false;
  selectedDays: string[] = [];

  readonly modeId = 'mode1';
  secondsList = [5, 10, 15, 20, 30, 45, 60, 90, 120];
  daysOfWeek = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];

  constructor(private frequencyService: FrequencyModeService) {}

  ngOnInit() {
    const mode = this.frequencyService.getMode(this.modeId);
    if (mode) {
      this.runTime = mode.runTime;
      this.stopTime = mode.stopTime;
      this.enabled = mode.enabled;
      this.selectedDays = mode.selectedDays;
    }
  }

  toggleDay(day: string) {
    if (this.selectedDays.includes(day)) {
      this.selectedDays = this.selectedDays.filter(d => d !== day);
    } else {
      this.selectedDays.push(day);
    }
  }

  toggleEnabled(event: Event) {
    const checked = (event.target as HTMLInputElement).checked;
    this.enabled = checked;
    this.frequencyService.setEnabled(this.modeId, checked);
  }

  saveSettings() {
    this.frequencyService.updateMode(this.modeId, this.runTime, this.stopTime, this.selectedDays);
    this.frequencyService.setEnabled(this.modeId, this.enabled);
    alert('✅ Frequency Mode saved!');
  }
}
